// src/shared/hooks/useAuditLog.ts
// Typed audit write helper

import { supabase } from '../../infrastructure/supabase/client';
import type { AuditAction } from '../../shared/types/database';

export interface AuditPayload {
  action: AuditAction;
  entityType: string;
  entityId: string;
  oldValues?: Record<string, unknown>;
  newValues?: Record<string, unknown>;
  changedFields?: string[];
  tenantId: string;  // ← REQUIRED: no longer optional
  metadata?: Record<string, unknown>;
}

export function useAuditLog() {
  const write = async (payload: AuditPayload) => {
    if (!payload.tenantId) {
      console.error('[useAuditLog] Refused: tenantId is required for audit trail');
      throw new Error('Missing tenant_id: audit trail requires tenant isolation');
    }

    const { error } = await supabase.from('audit_trail').insert({
      action: payload.action,
      entity_type: payload.entityType,
      entity_id: payload.entityId,
      old_values: (payload.oldValues ?? {}) as any,
      new_values: (payload.newValues ?? {}) as any,
      changed_fields: payload.changedFields ?? [],
      metadata: payload.metadata ?? {},
      tenant_id: payload.tenantId,
      created_at: new Date().toISOString(),
    } as any);

    if (error) {
      console.error('Audit write failed:', error);
    }
  };

  return { write };
}
